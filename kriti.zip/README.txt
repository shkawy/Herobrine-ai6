Herobrine AI (Fabric 1.21.11)
Type in normal chat:  herobrine hello   /  هيروبراين تعال   (also: kriti / كريتي / هيرو)
/kriti spawn  -> summon the Herobrine companion. Commands /kriti <msg> and /k <msg> still work.
Voice on phone: use the microphone key on your keyboard (Gboard) to dictate into chat.
Build: GitHub repo, upload kriti.zip, add .github/workflows/build.yml.
