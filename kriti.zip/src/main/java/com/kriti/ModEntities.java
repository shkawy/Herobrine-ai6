package com.kriti;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

public class ModEntities {
    public static final EntityType<HerobrineEntity> HEROBRINE = register();

    private static EntityType<HerobrineEntity> register() {
        ResourceKey<EntityType<?>> key = ResourceKey.create(Registries.ENTITY_TYPE,
                Identifier.fromNamespaceAndPath(Kriti.MOD_ID, "herobrine"));
        EntityType<HerobrineEntity> type = EntityType.Builder
                .of(HerobrineEntity::new, MobCategory.CREATURE)
                .sized(0.6f, 1.95f)
                .clientTrackingRange(8)
                .build(key);
        return Registry.register(BuiltInRegistries.ENTITY_TYPE, key, type);
    }

    public static void init() {
        FabricDefaultAttributeRegistry.register(HEROBRINE, HerobrineEntity.attributes());
    }
}
