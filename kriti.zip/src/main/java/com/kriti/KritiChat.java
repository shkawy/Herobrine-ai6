package com.kriti;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.monster.Monster;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class KritiChat {
    private static final HttpClient HTTP = HttpClient.newHttpClient();
    private static final Map<UUID, List<JsonObject>> HISTORY = new ConcurrentHashMap<>();
    private static final Set<UUID> BUSY = ConcurrentHashMap.newKeySet();
    private static final Random RNG = new Random();
    private static final Pattern ACTION = Pattern.compile("\\[ACTION:(FOLLOW|STAY|COME|ATTACK)\\]");

    private static final String SYSTEM =
            "You are Kriti, a friendly companion living inside the player's Minecraft world. "
          + "Chat casually like a friend. Always answer in the same language and dialect the player uses "
          + "(for example Iraqi Arabic if they write Iraqi Arabic). "
          + "Keep every reply short: one to three sentences, no markdown, no lists. "
          + "You also control a Herobrine-looking body standing next to the player. "
          + "When the player asks you to do something with it, add exactly one tag at the very end of your reply: "
          + "[ACTION:FOLLOW] to follow them, [ACTION:STAY] to stay where it is, [ACTION:COME] to come to them, "
          + "[ACTION:ATTACK] to attack nearby monsters. Only use a tag when the player really asks for that action. "
          + "Never mention the tags. You cannot mine or build yet; say so honestly if asked.";

    private static final String[] OFFLINE = {
            "هلا بيك! شلونك؟",
            "اني كريتي، رفيقك بالعالم. شنو نسوي اليوم؟",
            "حلو! كمل احجي وياي.",
            "هههه ضحكتني. شنو بعد؟",
            "حط مفتاح الـ API بملف kriti.json حتى أرد عليك بذكاء."
    };

    public static void talk(MinecraftServer server, ServerPlayer player, String text) {
        talk(server, player, text, true);
    }

    public static void talk(MinecraftServer server, ServerPlayer player, String text, boolean echo) {
        if (echo) player.sendSystemMessage(Component.literal("<" + player.getName().getString() + "> " + text));
        UUID id = player.getUUID();

        if (KritiConfig.apiKey.isBlank()) {
            String action = detectAction(text);
            String reply = action != null ? "حاضر!" : OFFLINE[RNG.nextInt(OFFLINE.length)];
            say(server, id, reply, action);
            return;
        }
        if (!BUSY.add(id)) {
            say(server, id, "استنى شوي، لسه أفكر...", null);
            return;
        }

        List<JsonObject> hist = HISTORY.computeIfAbsent(id, k -> new ArrayList<>());
        JsonObject user = new JsonObject();
        user.addProperty("role", "user");
        user.addProperty("content", text);
        final List<JsonObject> snapshot;
        synchronized (hist) {
            while (hist.size() > 10) { hist.remove(0); hist.remove(0); }
            hist.add(user);
            snapshot = new ArrayList<>(hist);
        }

        CompletableFuture.runAsync(() -> {
            String reply;
            String action = null;
            boolean ok = false;
            try {
                JsonObject body = new JsonObject();
                body.addProperty("model", KritiConfig.model);
                body.addProperty("max_tokens", 300);
                body.addProperty("system", SYSTEM);
                JsonArray msgs = new JsonArray();
                snapshot.forEach(msgs::add);
                body.add("messages", msgs);

                HttpRequest req = HttpRequest.newBuilder(URI.create("https://api.anthropic.com/v1/messages"))
                        .header("x-api-key", KritiConfig.apiKey)
                        .header("anthropic-version", "2023-06-01")
                        .header("content-type", "application/json")
                        .timeout(Duration.ofSeconds(30))
                        .POST(HttpRequest.BodyPublishers.ofString(body.toString(), StandardCharsets.UTF_8))
                        .build();
                HttpResponse<String> res = HTTP.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
                if (res.statusCode() == 200) {
                    JsonObject json = JsonParser.parseString(res.body()).getAsJsonObject();
                    reply = json.getAsJsonArray("content").get(0).getAsJsonObject().get("text").getAsString().trim();
                    Matcher m = ACTION.matcher(reply);
                    if (m.find()) action = m.group(1);
                    reply = ACTION.matcher(reply).replaceAll("").trim();
                    ok = true;
                } else if (res.statusCode() == 401) {
                    reply = "مفتاح الـ API غلط. تأكد منه بملف kriti.json";
                } else {
                    reply = "صار خطأ (" + res.statusCode() + "). جرب بعد شوي.";
                }
            } catch (Exception e) {
                reply = "ما كدرت أتصل بالإنترنت.";
            }

            synchronized (hist) {
                if (ok) {
                    JsonObject a = new JsonObject();
                    a.addProperty("role", "assistant");
                    a.addProperty("content", reply);
                    hist.add(a);
                } else if (!hist.isEmpty()) {
                    hist.remove(hist.size() - 1);
                }
            }
            BUSY.remove(id);
            say(server, id, reply, action);
        });
    }

    private static String detectAction(String t) {
        String s = t.toLowerCase();
        if (s.contains("تعال") || s.contains("come")) return "COME";
        if (s.contains("وقف") || s.contains("ابقى") || s.contains("stay")) return "STAY";
        if (s.contains("هاجم") || s.contains("attack")) return "ATTACK";
        if (s.contains("اتبعني") || s.contains("follow")) return "FOLLOW";
        return null;
    }

    private static void say(MinecraftServer server, UUID id, String message, String action) {
        server.execute(() -> {
            ServerPlayer p = server.getPlayerList().getPlayer(id);
            if (p == null) return;
            if (!message.isBlank()) p.sendSystemMessage(Component.literal("\u00a7b<Kriti>\u00a7r " + message));
            if (action != null) apply(p, action);
        });
    }

    private static void apply(ServerPlayer p, String action) {
        List<HerobrineEntity> list = p.level().getEntitiesOfClass(HerobrineEntity.class,
                p.getBoundingBox().inflate(256.0),
                e -> e.owner == null || p.getUUID().equals(e.owner));
        for (HerobrineEntity h : list) {
            h.owner = p.getUUID();
            switch (action) {
                case "FOLLOW" -> h.mode = HerobrineEntity.Mode.FOLLOW;
                case "STAY" -> {
                    h.mode = HerobrineEntity.Mode.STAY;
                    h.getNavigation().stop();
                }
                case "COME" -> {
                    h.mode = HerobrineEntity.Mode.FOLLOW;
                    h.setPos(p.getX(), p.getY(), p.getZ());
                    h.getNavigation().stop();
                }
                case "ATTACK" -> {
                    h.mode = HerobrineEntity.Mode.FOLLOW;
                    List<Monster> mobs = p.level().getEntitiesOfClass(Monster.class,
                            p.getBoundingBox().inflate(24.0), m -> !(m instanceof HerobrineEntity));
                    Monster best = null;
                    for (Monster m : mobs) {
                        if (best == null || m.distanceToSqr(p) < best.distanceToSqr(p)) best = m;
                    }
                    if (best != null) h.setTarget(best);
                }
                default -> { }
            }
        }
    }
}
