package com.kriti;

import java.util.EnumSet;
import java.util.UUID;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public class HerobrineEntity extends Zombie {
    public enum Mode { FOLLOW, STAY }

    public Mode mode = Mode.FOLLOW;
    public UUID owner;

    public HerobrineEntity(EntityType<? extends Zombie> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder attributes() {
        return Zombie.createAttributes()
                .add(Attributes.MAX_HEALTH, 60.0)
                .add(Attributes.ATTACK_DAMAGE, 8.0)
                .add(Attributes.MOVEMENT_SPEED, 0.3);
    }

    Player getOwnerPlayer() {
        if (owner != null) {
            Player p = this.level().getPlayerByUUID(owner);
            if (p != null) return p;
        }
        return this.level().getNearestPlayer(this, 64.0);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.2, true));
        this.goalSelector.addGoal(5, new FollowOwnerGoal(this));
        this.goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 8.0f));
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Monster.class, true));
    }

    @Override
    public boolean canAttack(LivingEntity target) {
        return !(target instanceof HerobrineEntity) && super.canAttack(target);
    }

    @Override
    protected boolean isSunSensitive() {
        return false;
    }

    @Override
    protected boolean convertsInWater() {
        return false;
    }

    @Override
    protected boolean shouldDespawnInPeaceful() {
        return false;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    static class FollowOwnerGoal extends Goal {
        private final HerobrineEntity mob;
        private int timer;

        FollowOwnerGoal(HerobrineEntity mob) {
            this.mob = mob;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            Player p = mob.getOwnerPlayer();
            return mob.mode == Mode.FOLLOW && p != null && mob.getTarget() == null
                    && mob.distanceToSqr(p) > 16.0;
        }

        @Override
        public boolean canContinueToUse() {
            Player p = mob.getOwnerPlayer();
            return mob.mode == Mode.FOLLOW && p != null && mob.getTarget() == null
                    && mob.distanceToSqr(p) > 6.0;
        }

        @Override
        public void tick() {
            Player p = mob.getOwnerPlayer();
            if (p == null) return;
            if (mob.distanceToSqr(p) > 576.0) {
                mob.setPos(p.getX(), p.getY(), p.getZ());
                mob.getNavigation().stop();
                return;
            }
            if (--timer <= 0) {
                timer = 10;
                mob.getNavigation().moveTo(p, 1.2);
            }
        }

        @Override
        public void stop() {
            mob.getNavigation().stop();
        }
    }
}
